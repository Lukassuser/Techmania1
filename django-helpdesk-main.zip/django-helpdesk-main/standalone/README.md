Django-helpdesk standalone
-------------------------------

This is a standalone installation of Django-helpdesk allowing you to run django-helpdesk as a production standalone application in docker.

For installation instructions see [the documentation](../docs/standalone.rst)

For development and testing purposes, the `docker-compose-dev.yml` file will build the standalone docker images from source.

